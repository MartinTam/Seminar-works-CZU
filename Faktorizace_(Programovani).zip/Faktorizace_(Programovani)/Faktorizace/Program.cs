﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Faktorizace
{
    internal class Program
    {
        static void NastaveniKonzole()
        {
            Console.Title = "Rozklad cisla na prvocinitele";
            Console.WindowHeight = 30;
            Console.WindowWidth = 100;

        }

        static void NastaveniPozadiKonzole()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
        }

        static void Nadpis()
        {
            Console.WriteLine("\t __________________________________________________________________________________");
            Console.WriteLine("\t|                                                                                  |");
            Console.WriteLine("\t|                 Rozklad cisla na prvocinitele (soucin prvocisel)                 |");
            Console.WriteLine("\t|__________________________________________________________________________________|\n");
        }

        static void HlavniMenu(int[] stav)
        {
            NastaveniPozadiKonzole();

            string vyberHlavniMenu;

            Nadpis();
            Console.WriteLine("\n\t\t\t\t\t    HLAVNI MENU");
            Console.WriteLine("\n\n\t\t1\tZadat vstupni hodnotu rucne");
            Console.WriteLine("\n\t\t2\tVygenerovat vstupni hodnotu");
            Console.WriteLine("\n\t\t3\tUkoncit program");
            Console.Write("\n\n\t\tVase volba: ");
            vyberHlavniMenu = Console.ReadLine();

            if (vyberHlavniMenu == "1")
            {
                stav[0] = 2;    // Prechod do stavu 2 = rucni zadavani vstupni hodnoty.
            }
            else if (vyberHlavniMenu == "2")
            {
                stav[0] = 3;    // Prechod do stavu 3 = nahodne generovani vstupni hodnoty.
            }
            else if (vyberHlavniMenu == "3")
            {
                stav[0] = 0;    // Prechod do stavu 0 = ukonceni programu.
            }
        }

        static void RucniZadani(int[] stav)
        {
            string vstup;
            long cislo;

            NastaveniPozadiKonzole();

            Nadpis();
            Console.WriteLine("\n\t\t\t\t\t    RUCNI ZADANI\n");            
            Console.Write("\n\t\tZadejte cislo: \t");
            vstup = Console.ReadLine();

            if (OsetrovaniVstupu(vstup))
            {
                cislo = long.Parse(vstup);

                /* Budeme rozkladat pouze kladna cela cisla v rozsahu datoveho typu integer.
                 * Pro vetsi cisla by byl vypocet casove narocnejsi.
                 */
                if (cislo > int.MaxValue)
                {
                    Console.WriteLine("\n\t\tVysledek: \tZadane cislo je prilis velike.");
                }
                else
                {
                    Faktorizace((int)cislo);
                }
            }
            else
            {
                Console.WriteLine("\n\t\tVysledek: \tNespravny vstup!");
            }

            /* Nechame uzivatele se rozhodnout, jak bude program dale pracovat.
             */
            Rozcesti(stav);
        }

        static void Generovani(int[] stav)
        {
            NastaveniPozadiKonzole();

            Nadpis();
            Console.WriteLine("\n\t\t\t\t     GENEROVANI NAHODNEHO VSTUPU\n");

            /* Vytvorime si novy objekt tridy "Random" a vyuzijeme jeji metodu "object.Next(int from, int to)"
             * na vygenerovani nahodneho cisla.
             */
            Random generovani = new Random();
            int generovaneCislo = generovani.Next(2, int.MaxValue);

            Console.WriteLine("\n\t\tNahodne cislo: \t{0}", generovaneCislo);
            Faktorizace(generovaneCislo);

            /* Nechame uzivatele se rozhodnout, jak bude program dale pracovat.
             */
            Rozcesti(stav);
        }

        static void Rozcesti(int[] stav)
        {
            string vyberRozcesti;

            Console.WriteLine("\n\n\t\t\t------------------------------------------------------");
            Console.WriteLine("\n\n\t\t1\tProvest znovu");
            Console.WriteLine("\n\t\t2\tZpet do hlavniho menu");
            Console.WriteLine("\n\t\t3\tUkoncit program");
            Console.Write("\n\n\t\tVase volba: ");

            vyberRozcesti = Console.ReadLine();

            if (vyberRozcesti == "2")
            {
                stav[0] = 1;    // Prechod do stavu 1 = hlavni menu.
            }
            else if (vyberRozcesti == "3")
            {
                stav[0] = 0;    // Prechod do stavu 0 = ukonceni programu.
            }
            else if (vyberRozcesti == "1")
            {
                // Nic nastavovat nemusime, hodnota stav[0] zustava stejna. Tudiz provedeme soucasny stav znovu.
            }
            else
            {
                /* Pokud uzivatel zada jine, nesmyslne vstupy nez cisla oznacujici jednotlive volby,
                 * budeme uzivateli zobrazovat moznosti volby, co se ma s programem dale stat tak dlouho,
                 * dokud nezada jednu z nabizenych voleb.
                 */

                if (stav[0] == 2)   // Simulace obrazovky soucasneho stavu.
                {
                    Console.Clear();
                    Nadpis();
                    Console.WriteLine("\n\t\t\t\t\t    RUCNI ZADANI\n");
                    Rozcesti(stav);
                }
                else if (stav[0] == 3)  // Simulace obrazovky soucasneho stavu.
                {
                    Console.Clear();
                    Nadpis();
                    Console.WriteLine("\n\t\t\t\t     GENEROVANI NAHODNEHO VSTUPU\n");
                    Rozcesti(stav);
                }
            }

        }

        static bool OsetrovaniVstupu(string vstup)
        {
            bool kontrolaPretypovani;
            long pretypovaneCislo;

            /* Zkontrolujeme, zda zadany vstup od uzivatele je opravdu kladne cele cislo.
             */
            kontrolaPretypovani = long.TryParse(vstup, out pretypovaneCislo);

            if (kontrolaPretypovani && pretypovaneCislo >= 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static void Faktorizace(int n)
        {
            int i = 2;
            string rozkladaneCislo = n.ToString();
            string rozklad = "";

            /* Pokud "i" je delitelny "n" bez zbytku, pak "i" uz musi byt prvocislo.
             * Protoze v predchozim prubehu cyklem jsme jiz napr. vypsali vsechny dvojky v rozkladu.
             * Tudiz k zadnym sudym cislum vetsim nez 2 se uz nedostaneme.
             * Podobna analogie lze uplatnit i na nasobky 3, 5, 7, atd.
             */
            while (i <= n)
            {
                if (n % i == 0)
                {
                    rozklad = rozklad + i.ToString() + " * ";
                    n = n / i;
                }
                else
                {
                    i++;
                }
            }

            // Odstranime znamenko "*" ve vypisu za poslednim prvocislem.
            rozklad = rozklad.Remove(rozklad.Length - 3);

            if (rozkladaneCislo == rozklad)
            {
                // Pokud nase "rozkladaneCislo" se rovna "rozklad", pak to znamena, ze "rozkladaneCislo" je prvocislo.                 
                Console.WriteLine("\n\t\tVysledek: \t{0} uz je prvocislo.", rozkladaneCislo);
            }
            else
            {
                Console.WriteLine("\n\t\tVysledek:\t" + rozkladaneCislo + " = " + rozklad);
            }

        }
        
        static void Main(string[] args)
        {
            NastaveniKonzole();

            /* Ukazatel stavu deklarujeme jako pole, jelikoz pole se do funkci predava odkazem
             * na jejich misto ulozeni v pameti a ne pouze kopie jeho hodnoty. Tudiz, pokud
             * uvnitr funkce hodnotu pole zmenime, projevi se tato zmena prepsanim i hodnoty v poli.
             */
            int[] stav = new int[1];
            stav[0] = 1;            

            /* Stavy:   0   -   Ukonceni programu
             *          1   -   Hlavni menu
             *          2   -   Rucni zadani vstupni hodnoty uzivatelem
             *          3   -   Generovani nahodne vstupni hodnoty pocitacem
             */

            // Jakmile nastane "stav[0] = 0", tak while cyklus skonci a ukonci se i cely nas program.
            while (stav[0] != 0)
            {
                if (stav[0] == 1)
                {
                    HlavniMenu(stav);
                }
                else if (stav[0] == 2)
                {
                    RucniZadani(stav);
                }
                else if (stav[0] == 3)
                {
                    Generovani(stav);
                }                
            }
                  
        }
    }
}
